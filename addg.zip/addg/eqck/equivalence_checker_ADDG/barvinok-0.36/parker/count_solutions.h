double count_solutions(Relation& r);
