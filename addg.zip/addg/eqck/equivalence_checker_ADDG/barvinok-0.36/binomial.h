#include <barvinok/polylib.h>

#if defined(__cplusplus)
extern "C" {
#endif

Value *binomial(unsigned n, unsigned k);
Value *factorial(unsigned n);

#if defined(__cplusplus)
}
#endif
