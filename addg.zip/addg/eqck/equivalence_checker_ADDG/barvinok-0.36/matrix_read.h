#include <iostream>
#include <barvinok/polylib.h>
#include "conversion.h"

Matrix *Matrix_Read(std::istream& is);
