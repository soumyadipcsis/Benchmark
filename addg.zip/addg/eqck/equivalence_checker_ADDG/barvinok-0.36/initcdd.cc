#include "initcdd.h"

int bv_cdd_initialized = 0;
