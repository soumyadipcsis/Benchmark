#include <iostream>
#include <gmp.h>
#include <barvinok/evalue.h>

void evalue_print(std::ostream& o, evalue *e, char **p);
