/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    
    int i,j,N;
    
    scanf("%d",&N);//taking input from the user
    
    for(i=1;i<=N;i++)
    {
        for(j=N;j>0&&j>i;j=j-1)
        {
            printf("%d",j);
        }
        printf("*");
        
        for(j=i-1;j>0;j--)
        {
            printf("%d",j);
        }
        
        j=N;
        
        printf("\n");
    }
	return 0;
}