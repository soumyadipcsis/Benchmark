/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int n;// variable declaration
    scanf("%d",&n);// storing no.
    for(int i=1;i<=n;i++)// outer loop
    {
    for(int j=n;j>=1;j--)// inner loop
    {
    if(j==i)
    {
    printf("*");
    }
    else
    printf("%d",j);
    }                   // end of inner loop    
    printf("\n");
    }               // end of outer loop    
	return 0;
}