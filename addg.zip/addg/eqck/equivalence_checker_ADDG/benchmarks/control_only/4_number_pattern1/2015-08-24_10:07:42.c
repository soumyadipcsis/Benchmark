/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
	//Enter your code here
	int N;            //declaring variable
	scanf("%d",&N);   //input from user
	for(int a=1;a<=N;a++){
	    for(int b=N;b>=1;b--)
	    {
	        if(a==b)
	        printf("%c",'*');
	        else printf("%d",b);
	    }
	    printf("\n");
	}
	return 0;
}