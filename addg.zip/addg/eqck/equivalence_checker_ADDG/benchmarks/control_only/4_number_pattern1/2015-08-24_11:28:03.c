/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main(){
int x;
scanf("%d",&x);
for(int j=1;j<=x;j++){
    for (int i=x;i>0;i--){
    if (j==i)
    printf("*");
    else
        printf("%d",i);
    }
    printf("\n");
}
        return 0;
}
