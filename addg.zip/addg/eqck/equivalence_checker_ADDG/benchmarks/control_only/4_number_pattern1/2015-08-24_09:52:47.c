/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N;//assigning variable
	scanf("%d",&N);//input of variable
	int i,j;
	for(j=1;j<=N;j++){
	    for(i=N;i>=1;i--){
            if(i!=j){
                printf("%d",i);//printing of number
            }else{
                printf("*");//substitution of appropriate number with *
            }
	    }
	    printf("\n");//change of line
	}
	return 0;
}