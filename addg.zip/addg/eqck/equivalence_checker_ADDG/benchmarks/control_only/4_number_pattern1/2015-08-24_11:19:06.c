/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int i;
	int j;
	int x;
	scanf("%d",&x);
	
	for (i=x;i>=1;i=i-1)  {
	    for (j=x; j>=1; j=j-1) {printf("%d", j);}
	printf("\n"); 
	    
	}
	return 0;
}