/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N;
	scanf("%d", &N);
	for (int i = 1; i <= N; i++){ //To accomodate no of lines
	    for (int j = N; j > 0; j--){ //To print different numbers
	        if (j == i){ //To check if * is to be printed
	            printf("*");
	        }
	        else {
	            printf("%d", j);
	        }
	    }
	    printf("\n");
	}
	return 0;
}