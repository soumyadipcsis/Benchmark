/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){ 
    int i,j,N;                   /*declaring the variables*/
    scanf("%d",&N);              /*input by the user*/
    for (i=N;i>=1;i=i-1) 
    {                            /*starting the loop*/
        for(j=N;j>=1;j=j-1)
        if (i+j==N+1)
        {                        /*putting the condition*/
            printf("*");
        }
        else 
        {
            printf("%d",j);
        }                  
            printf("\n");
    }                            /*exiting the loop*/
    return 0;
}