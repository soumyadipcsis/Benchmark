/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int i;
	int n; //input value
	int j;
	scanf("%d",&n);

    for (j=1;j<=n;j=j+1){ //loop to change columns
    	for (i=n;i>=1;i=i-1) // loop to print the numbers
	    { if(j==i)  
	        {
	        printf("*");  //replace the no. by star
	    }
	    else
	        printf("%d",i);
	    }
	    printf("\n");
    }
	return 0;
}