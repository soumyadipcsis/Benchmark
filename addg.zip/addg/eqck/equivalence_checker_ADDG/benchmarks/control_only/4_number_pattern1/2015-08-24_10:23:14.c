/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a;
    scanf("%d",&a);/*input*/
    int i,j;/*i is defined for printing the number and j is defined for                 printing number of lines*/
    char c;
    c='*';
    for(j=1;j<=a;j=j+1)
    {
        for(i=a;i>=1;i=i-1)
        {
           if (i==j)
           {
               printf("%c",c);
           }
           else
           {
               printf("%d",i);
           }
        }
        printf("\n");
    }   
	return 0;
}