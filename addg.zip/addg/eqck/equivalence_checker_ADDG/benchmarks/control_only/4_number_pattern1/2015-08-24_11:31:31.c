/*compile-errors:e158_277717.c:7:21: warning: multiple unsequenced modifications to 'j' [-Wunsequenced]
    for(j=N;j>=1;j=j++){
                  ~ ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
int i,j,N;
scanf("%d",&N);
for(i=N;i>=1;i++){
    for(j=N;j>=1;j=j++){
printf("%d",j);
}
printf("\n");
}//Enter your code her
	return 0;
}