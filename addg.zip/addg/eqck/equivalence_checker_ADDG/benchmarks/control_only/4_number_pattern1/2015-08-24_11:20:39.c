/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    int N ,  k =0 ;
    scanf("%d",&N);
	for (int i=1  ; i<=N ;k++, i++){
	    for (int j =1 ; j<=N ; j++){
	        if (j== (N-k)){
	            printf("*") ;
	            continue ;
	            //for every N-k spot , it will print * and then continue will take it back to j counter , and not carry out the next step in loop .
	        }
	        printf ("%d",(N+1)-j);
	        // since j is initialised with value of 1 , we will have to print N+1 - j as that is the number corresponding to j position in row 
	        }
	    printf("\n");
	}
    return 0 ;
}