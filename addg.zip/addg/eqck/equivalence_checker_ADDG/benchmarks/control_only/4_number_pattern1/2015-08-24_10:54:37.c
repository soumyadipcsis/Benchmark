/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N;
	scanf("%d",&N);//input the number
	
	int i,j;
	
	for(i=1;i<=N;i++)//for changing the line
	{
	   for(j=1;j<=N;j++)//for printing the pattern in each line
	   {
	       if(j==(N+1-i))// test condition for the * place
	       {
	           printf("*");
	           
	       }
	       else
	       {
	           printf("%d",(N+1-j));
	       }
	   }
	   printf("\n");
	}
	return 0;
}