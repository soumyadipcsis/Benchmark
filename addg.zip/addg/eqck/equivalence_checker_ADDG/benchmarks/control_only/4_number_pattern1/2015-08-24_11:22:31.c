/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
int N;            /*current int*/
scanf("%d",&N);                  /*input N*/

for(int i=1;i<=N;i=i+1){
for(int k=N;k>=1;k--){if(k==i)
{printf("*");}                  /*print the output*/
    else {printf("%d",k);}
    
}
printf("\n");        /*give the new line*/
}
	return 0;
}