/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    int N;
	scanf("%d",&N);
	int i,j;//variables for rows and columns respectively
	for(i=1;i<=N;i++)//keeps count of rows
	{
	    for(j=N;j>=1;j--) //reverse values of column printed 
	    {                 //so j iterates in reverse order 
	        if(j==i)//condition fulfilled on right diagonal
	            printf("*");
	        else
	            printf("%d",j);
	    }
	    printf("\n");//moving to next line after printing a row 
	}
	return 0;
}