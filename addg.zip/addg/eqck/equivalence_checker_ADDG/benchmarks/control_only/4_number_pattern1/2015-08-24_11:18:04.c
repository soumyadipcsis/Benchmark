/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
    int n;
    scanf("%d", &n);
    int i=n;
    int r=1;
    while(r<=n){
        while((i<=n)&&(i>0)){
            if(i==r){
            printf("*");
            }else{
            printf("%d", i);
            }
            i=i-1;
        }
        r++;
        i=n;/*will start the loop again.*/
        printf("\n");
    }
	return 0;
}
