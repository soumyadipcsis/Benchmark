/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int n;
	scanf("%d",&n);
	int i;
	for(i=1;i<=n;i++)
	{
     int j;
	 for(j=n;j>=1;j--)
	    {
	     if (i==j)
	     printf("*");
	     else
	     printf("%d",j);
	    }  
	 printf("\n");
	}
	return 0;
}