/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
	int N;
	scanf("%d",&N);
	for (int i=1;i<=N;i++)//to count the number of lines to be printed
	{
	    for (int j=N;j>=1;j--)//to print the numbers sequentially
	    {
	        if(j==i)//to check the position of *
	            printf("*");
	        else
	            printf("%d",j);
	    }
	    printf("\n");//for moving to the next line
	}
	return 0;
}