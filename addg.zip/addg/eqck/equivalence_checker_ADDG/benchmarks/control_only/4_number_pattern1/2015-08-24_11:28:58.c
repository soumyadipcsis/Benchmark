/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	
	int N;                      //N=Number of rows.
	scanf("%d",&N);             //Getting N as input from user.     
	int i,j,k;                  //i,j,k variables to be used in loops.
	
	for(i=1;i<=N;i++)           //Loop I for number of rows. 
	{  
	    for(j=N;j>i;j--)        //Loop II for left side pattern.
	    printf("%d",j);
	    
	    printf("*");
        
        for(k=(i-1);k>=1;k--)   //Loop III for Right side pattern.
        printf("%d",k);
        	
	    printf("\n");
	}
	
	return 0;
}