/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int i,j,N;
	scanf("%d",&N);
	for (i=N;i<=N && i>0;i--){
	    for (j=N;j<=N && j>0;j=j-1){
	        if (j==N-i+1) {printf("*");}
	        else{
	        printf("%d",j);}
	    }
	    printf("\n");
	}
	return 0;
}