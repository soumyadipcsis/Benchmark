/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N;
	scanf("%d",&N);                //Taking the number as input
	for(int i=1;i<=N;i++)          //Using nested loop to print series
	    {
	        for(int j=N;j>=1;j--)  //Printing the series
	        {
	            if(j==i)
	            {
	                printf("*");    //Printing * at desired places
	            }
	            else
	            {
	                printf("%d",j); //Printing the numbers
	            }
	        }
	        
	        printf("\n");           //Printing newline after series end 
	    }
	return 0;
}