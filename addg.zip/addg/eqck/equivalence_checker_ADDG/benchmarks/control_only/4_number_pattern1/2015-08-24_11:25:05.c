/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main(){
	int N,i,j;
	scanf("%d",&N);
	i=N;
	j=N;
	while(i>0){ //condition for rows
	    N=j;
	    while(N>0){  //condition for columns
	        if(i+N==(j+1)){ //pattern for printing *
	            printf("*");
	        }
	        else {
	            printf("%d",N);
	        }
	        N=N-1;
	    }
	    printf("\n");
	    i=i-1;
	}
	return 0;
}