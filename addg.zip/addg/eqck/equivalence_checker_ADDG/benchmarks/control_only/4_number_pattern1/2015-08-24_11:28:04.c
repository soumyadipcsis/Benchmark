/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N; // variable for storing digit
    scanf("%d",&N); // taking input from the user
    int i; // temporary
    for (i=N;i>=1;i--) //outer loop generate the rows
    {
        int j; // temporary
        for (j=N;j>=1;j--) //inner loop generate numbers
        {
            if (i+j==N+1) // condition for *
            printf("*"); // display the output on the console
            else             
            printf("%d",j); // display the output on the console

        }
        printf("\n"); // \n stands for changes the line
        
    }

	return 0;
}