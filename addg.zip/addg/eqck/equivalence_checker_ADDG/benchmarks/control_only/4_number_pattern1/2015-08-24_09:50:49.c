/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int N;
    scanf("%d",&N);//Input variable.
    for(int i=1;i<=N;i++)//Loop for switching rows.
    {   
        for(int j=1;j<=N;j++)//Loop for switching and printing columns.
        {
            if(j==N+1-i)
            {  
                printf("*");
            }
            else
            {
                printf("%d",N+1-j);
            }
        }
        printf("\n");
    }
	return 0;
}