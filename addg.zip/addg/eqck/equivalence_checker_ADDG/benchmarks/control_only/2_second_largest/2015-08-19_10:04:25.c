/*execute-result:OK*/
/*compile-errors:e156_271588.c:37:13: warning: variable 'min' is used uninitialized whenever 'if' condition is false [-Wsometimes-uninitialized]
    else if(max!=d && max!=a && max!=b)
            ^~~~~~~~~~~~~~~~~~~~~~~~~~
e156_271588.c:45:46: note: uninitialized use occurs here
    printf("The second largest number is %d",min); /*successfully found*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{   int a,b,c,d,max,min;     /*declaring the variables*/
    scanf("%d""%d""%d""%d",&a,&b,&c,&d); /*feeding values*/
    if(a>b && a>c && a>d)          /*checking the maximum value*/
           max=a;
    else if(b>a && b>c && b>d)
           max=b;
    else if(c>a && c>b && c>d)
           max=c;
    else if(d>a && d>b && d>c)
           max=d;                   /*got the maximum value*/
     
    if(max!=a && max!=b && max!=c)   /*searching the block....*/
            {  if(a>b && a>c)        /*where the next maximum...*/
                  min=a;             /*is to be found.....*/
               else if(b>a && b>c)
                  min=b;
               else min=c;
            }
       
    else if (max!=b && max!=c && max!=d)
            {  if(b>c && b>d)
                  min=b;
               else if(c>b && c>d)
                  min=c;
               else min=d;
            }
    else if (max!=c && max!=d && max!=a)
            {  if(c>d && c>a)
                 min=c;
               else if(d>c && d>a)
                 min=d;
               else min=a;
            }
    else if(max!=d && max!=a && max!=b)
            {  if(d>a && d>b)
                 min=d;
               else if(a>d && a>b)
                 min=a;
               else min=b;
            }
         
    printf("The second largest number is %d",min); /*successfully found*/
     

    // Fill this area with your code.
    return 0;
}