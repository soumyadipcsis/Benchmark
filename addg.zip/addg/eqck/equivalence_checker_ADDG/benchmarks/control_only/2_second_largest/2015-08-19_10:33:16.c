/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a1,a2,a3,a4,swap,smax,max;
    scanf("%d %d %d %d",&a1,&a2,&a3,&a4);
        if(a1>a2)               //taking smaller amongst these as smax
            {smax=a2;
            max=a1;             //larger num as max
            }
        else
            {
                smax=a1;
                max=a2;
            }
        if(smax<a3)           //swapping and comparison of smax with a3
            smax=a3;
        if(smax>max)          //taking smax smaller than largest num
            {
                swap=smax;
                smax=max;
                max=swap;
            }    
        if(smax<a4)         //swapping and comparison with a4
            smax=a4;
        if(smax>max) 
            {               //checking and swapping for max and smax
                swap=smax;
                smax=max;
                max=swap;
            }    
    printf("The second largest number is %d",smax);    
    return 0;
}