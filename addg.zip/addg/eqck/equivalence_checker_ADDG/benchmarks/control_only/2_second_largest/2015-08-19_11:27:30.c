/*execute-result:OK*/
/*compile-errors:e156_271536.c:21:17: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
       else if(a=b && b<c) 
               ~^~~~~~~~~
e156_271536.c:21:17: note: place parentheses around the assignment to silence this warning
       else if(a=b && b<c) 
                ^
               (         )
e156_271536.c:21:17: note: use '==' to turn this assignment into an equality comparison
       else if(a=b && b<c) 
                ^
                ==
e156_271536.c:23:17: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
       else if(a=b && b>c)
               ~^~~~~~~~~
e156_271536.c:23:17: note: place parentheses around the assignment to silence this warning
       else if(a=b && b>c)
                ^
               (         )
e156_271536.c:23:17: note: use '==' to turn this assignment into an equality comparison
       else if(a=b && b>c)
                ^
                ==
e156_271536.c:48:15: warning: variable 'large' is used uninitialized whenever 'if' condition is false [-Wsometimes-uninitialized]
      else if(d>b)     
              ^~~
e156_271536.c:56:46: note: uninitialized use occurs here
    printf("The second largest number is %d",large);//printing output
                                             ^~~~~
e156_271536.c:48:12: note: remove the 'if' if its condition is always true
      else if(d>b)     
           ^~~~~~~~~~~~
e156_271536.c:38:16: warning: variable 'large' is used uninitialized whenever 'if' condition is false [-Wsometimes-uninitialized]
       else if(b>d && d<a && c>d && a<c)
               ^~~~~~~~~~~~~~~~~~~~~~~~
e156_271536.c:56:46: note: uninitialized use occurs here
    printf("The second largest number is %d",large);//printing output
                                             ^~~~~
e156_271536.c:38:13: note: remove the 'if' if its condition is always true
       else if(b>d && d<a && c>d && a<c)
            ^~~~~~~~~~~~~~~~~~~~~~~~~~~~
e156_271536.c:38:16: warning: variable 'large' is used uninitialized whenever '&&' condition is false [-Wsometimes-uninitialized]
       else if(b>d && d<a && c>d && a<c)
               ^~~~~~~~~~~~~~~~~
e156_271536.c:56:46: note: uninitialized use occurs here
    printf("The second largest number is %d",large);//printing output
                                             ^~~~~
e156_271536.c:38:16: note: remove the '&&' if its condition is always true
       else if(b>d && d<a && c>d && a<c)
               ^~~~~~~~~~~~~~~~~~~~
e156_271536.c:38:16: warning: variable 'large' is used uninitialized whenever '&&' condition is false [-Wsometimes-uninitialized]
       else if(b>d && d<a && c>d && a<c)
               ^~~~~~~~~~
e156_271536.c:56:46: note: uninitialized use occurs here
    printf("The second largest number is %d",large);//printing output
                                             ^~~~~
e156_271536.c:38:16: note: remove the '&&' if its condition is always true
       else if(b>d && d<a && c>d && a<c)
               ^~~~~~~~~~~~~
e156_271536.c:38:16: warning: variable 'large' is used uninitialized whenever '&&' condition is false [-Wsometimes-uninitialized]
       else if(b>d && d<a && c>d && a<c)
               ^~~
e156_271536.c:56:46: note: uninitialized use occurs here
    printf("The second largest number is %d",large);//printing output
                                             ^~~~~
e156_271536.c:38:16: note: remove the '&&' if its condition is always true
       else if(b>d && d<a && c>d && a<c)
               ^~~~~~
e156_271536.c:23:16: warning: variable 'large' is used uninitialized whenever 'if' condition is false [-Wsometimes-uninitialized]
       else if(a=b && b>c)
               ^~~~~~~~~~
e156_271536.c:56:46: note: uninitialized use occurs here
    printf("The second largest number is %d",large);//printing output
                                             ^~~~~
e156_271536.c:23:13: note: remove the 'if' if its condition is always true
       else if(a=b && b>c)
            ^~~~~~~~~~~~~~
e156_271536.c:5:22: note: initialize the variable 'large' to silence this warning
    int a,b,c,d,large;//declaration of variables
                     ^
                      = 0
8 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,d,large;//declaration of variables
    scanf("%d%d%d%d",&a,&b,&c,&d);//input
    if(a>=b)//condition
{     
       if(a>c && d>a)
          large=a;
       else if(a>d && a<c)
          large=a;
       else if(a<d && c>d)      
          large=d;
       else if(a<c && d>c)
          large=c;
       else if(b>c && c>d)
          large=b;
       else if(d>c && d>b)
          large=d;
       else if(a=b && b<c) 
          large=a;
       else if(a=b && b>c)
          large=c;
}
    else if(b>c)
{   
       if(b<d)
          large=b;
       else if(b>d && d>a && d>c)
          large=d;
       else if(b>d && d<a && d>c)
          large=a;
       else if(b>d && d>a && d<c)
          large=c;
       else if(b>d && d<a && c>d && c<a)       
          large=a;
       else if(b>d && d<a && c>d && a<c)
          large=c;
    
}
    else if(c>=d)
{   
      if(d<a)
         large=b;
      else if(d<b)
         large=b;
      else if(d>b)     
         large=d;
}       
    else 
{    
      large=c;
    
}
    printf("The second largest number is %d",large);//printing output
    return 0;//end of program
}