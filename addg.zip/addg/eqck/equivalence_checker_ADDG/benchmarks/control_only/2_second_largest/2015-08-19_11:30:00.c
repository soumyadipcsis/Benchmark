/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
int main()
{
    int m,s,a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    m=a;
    s=0;
    if (b>m)
    {
        s=m;
        m=b;
    }
    else if (b>s)
    {
        s=b;
    }
    if (c>m)
    {
        s=m;
        m=c;
    }
    else if (c>s)
    {
        s=c;
    }
    if (d>m)
    {
        s=m;
        m=d;
    }
    else if (d>s)
    {
        s=d;
    }
    printf("The second largest number is %d",s);
    return 0;
}