/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,d;
    scanf("%d""%d""%d""%d",&a,&b,&c,&d);
    if (a>b && b>c&& c>d)
    {
    printf("The second largest number is %d",b);
    }
    if (b>a && a>c&&c>d)
    {
    printf("The second largest number is %d",a);
    }
    if (a>c && c>b&&b>d)
    {
    printf("The second largest number is %d",c);
    }
    if (b>c && c>a&&a>d)
    {
        printf("The second largest number is %d",d);
    }
    if (c>a&&a>b&&b>d)
    {
        printf("The second largest number is %d",a);
    }
    if (c>b&&b>a&&a>d)
    {
            printf("The second largest number is %d",b);
    }
    if (b>c&&c>d&&d>a)
    {
            printf("The second largest number is %d",c);
    }
    if (b>d&&d>c&&c>a)
    {
            printf("The second largest number is %d",d);
    }
    if (c>b&&b>d&&d>a)
    {
            printf("The second largest number is %d",b);
    }
    if (c>d&&d>b&&b>a)
    {
            printf("The second largest number is %d",d);
    }
    if (d>b&&b>c&&c>a)
    {
            printf("The second largest number is %d",b);
    }
    if (d>c&&c>b&&b>a)
    {
            printf("The second largest number is %d",d);
    }
    if (a>c&&c>d&&d>b)
    {
                printf("The second largest number is %d",c);
}
 if (a>d&&d>c&&c>b)
 {
             printf("The second largest number is %d",d);
 }
 if(d>c&&c>a&&a>b)
 {
             printf("The second largest number is %d",c);
 }
 if(d>a&&a>c&&c>b)
 {
             printf("The second largest number is %d",a);
 }
 if(c>d&&d>a&&a>b)
 {
             printf("The second largest number is %d",d);
}
if(c>a&&a>d&&d>b)
{
            printf("The second largest number is %d",a);
}
if(a>b&&b>d&&d>c)
{
            printf("The second largest number is %d",b);
}
if(a>d&&d>b&&b>c)
{
            printf("The second largest number is %d",d);
}
if(b>a&&a>d&&d>c)
{
            printf("The second largest number is %d",a);
}
if(b>d&&d>a&&a>c)
{
            printf("The second largest number is %d",d);
}
if(d>a&&a>b&&b>c)
{
            printf("The second largest number is %d",a);
}
if(d>b&&b>a&&a>c)
{
            printf("The second largest number is %d",b);
}
return 0;
}