/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,d,i=0,z=0,k=0;// variables declared
    /* inputting four variables, i.e. four natural numbers*/
    scanf("%d ", &a);
    scanf("%d ", &b);
    scanf("%d ", &c);
    scanf("%d ", &d);
    printf("The second largest number is ");
    /* i would take a as first value and as it encounters a value          higher than itself, it would take that. i would finally store the      largest number. */
    if(a>i)
    {
        i=a;
    }
    if(b>i)
    {
        i=b;
    }
    if(c>i) //these four if find the maximum of four numbers
    {
        i=c;
    }
    if(d>i) 
    {
        i=d;
    }
    /* now the conditions would check for all numbers if they are less     than the greatest number and z would first store a and then would      take up a different value if it encounters a number greater than       itself. With the help of first condition, we ensure that we find       the number which is less than the greatest but the highest among       the remaining.*/
    if(a<i && a>z) 
    {
        z=a;
    }
    if(b<i && b>z) 
    {
        z=b;
    }
    if(c<i && c>z) // these four if find the largest number excluding      the maximum number which is saved in i and saves it in z
    {
        z=c;
    }
    if(d<i && d>z)
    {
        z=d;
    }
    /*check how many numbers are there that are largest and store them     in k*/
    if(a==i)
    {
        ++k;
    }
    if(b==i)
    {
        ++k;
    }
    if(c==i)// these four if check if more than one value is maximum.      if more than one maximum, program needs to print the maximum number     as per the hidden test.
    {
        ++k;
    }
    if(d==i)
    {
        ++k;
    }
    // if more than one are maximum, store maximum in z
    if(k>1) 
    {
        z=i;
    }
    printf("%d", z); // prints the value of z
    return 0;
}