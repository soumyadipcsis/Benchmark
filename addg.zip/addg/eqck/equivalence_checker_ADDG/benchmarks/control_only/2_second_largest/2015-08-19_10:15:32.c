/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{   
    int a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    int smax,max;
    // considering max and second max from first two numbers
    if(a>=b)
    {
        max = a;
        smax = b;
    }
    else
    {
        max = b;
        smax = a;
    }
    if(c>max)       //comparing max and smax with the third number 
    {
        smax = max; //swapping if true condition
        max = c;    //updating max
    }
    else if(c>smax)
    {
        smax = c;   
    }
    if(d>max)
    {
        smax=max; //swapping if condition is true
    }
    else if(d>smax)
    {
        smax=d;
    }
    printf("The second largest number is %d",smax);
    return 0;
}