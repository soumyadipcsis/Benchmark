/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{     
    int a,b,c,d,temp,x;
    scanf("%d %d %d %d",&a,&b,&c,&d);//input
    if(a<b){
        temp=a;     //to find larger one between a and b
        a=b;         //swapping
        b=temp;
        
    }
    if(b<c){
        temp=b;     //to find larger one between b and c
        b=c;
        c=temp;
        
    }
    if(c<d){         
        temp=c;      //to find larger one between c and d
        c=d;
        d=temp;
        
    }
    if(a<b){
        temp=a;      //to find larger one beteween a and b
        a=b;
        b=temp;
        
    }
    if(b<c){
        temp=b;       //to find larger one between b and c
        b=c;
        c=temp;
    
    }
    if(a<b){
        temp=a;        //to find larger one between a and b
        a=b;
        b=temp;
        
    }
    
    if(a==b){
      if(b==c)
         x=d;       //to incorporate the cases in whch any two numbers                                         are equal
      else
         x=c;
    }     
    else
      x=b;
    /*   An alternative code 
         Flaw:can not incorporate equalities
    if((((b-a)*(b-c)*(b-d))<0)&&(!((b<a)&&(b<c)&&(b<d))))
    x=b;
    if((((a-b)*(a-c)*(a-d))<0)&&(!((a<b)&&(a<c)&&(a<d))))
    x=a;                                                            
    if((((c-a)*(c-b)*(c-d))<0)&&(!((c<a)&&(c<b)&&(c<d))))
    x=c;
    if((((d-a)*(d-b)*(d-c))<0)&&(!((d<a)&&(d<b)&&(d<c))))
    x=d;*/
    printf("The second largest number is %d",x);//output
    return 0;
}