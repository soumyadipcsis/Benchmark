/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
    /*......Second largest number.....*/
{     
    int a,b,c,d;
    int M,m;   /* M=largest number m=second largest number */
    scanf("%d %d %d %d",&a,&b,&c,&d);
    if(a>b)
    {
      M=a;
      m=b;
    }
     else 
    {
      M=b;
      m=a;
     }
      if(c>M)
    {
      m=M;
      M=c;
    }
      else if  (c>m)
    {
      m=c;
    }
      if(d>M){
       m=M;
       M=d;
    }
      else if (d>m)
    {
      m=d;
    }
      printf("The second largest number is %d",m);
                
    return 0;
}