/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,d,p,q;
    scanf("%d%d%d%d",&a,&b,&c,&d);
    p=a;
    q=a;
    
    if(b>p)
    {
        p=b;
    }
    else
    {
        q=b;
    }
    if(c>p)
    {
        q=p;
        p=c;
    }
    
    else
    {  if(c>q)
       {
         q=c;
       }
    }
    if(d>p)
    {
        printf("The second largest number is %d",p);
    }
    else
    { if(d>q)
      {
        printf("The second largest number is %d",d);
      }
    else
    {
        printf("The second largest number is %d",q);}
    }
    return 0;
}