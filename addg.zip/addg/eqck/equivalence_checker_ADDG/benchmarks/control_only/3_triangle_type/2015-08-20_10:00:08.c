/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c,tmp;// tmp as temporary variable for swapping
    scanf("%d%d%d",&a,&b,&c);
    if(a>c)       // to check largest side 
    {
            tmp=c;// swapping
            c=a;
            a=tmp;
    }
    if(b>c)       // to check largest side
    {
        tmp=c;    // swapping
        c=b;
        b=tmp;
    }
    if((a+b>c)&&(b+c>a)&&(c+a>b)) // checking property of triangle
    {
            if(((a*a)+(b*b))==(c*c))// checking for right triangle
            printf("Right Triangle");
        else
            if(((a*a)+(b*b))<(c*c)) // checking for obtuse triangle
            printf("Obtuse Triangle");
        else
            if(((a*a)+(b*b))>(c*c)) // checking for acute triangle
            printf("Acute Triangle");
    }
    else
    printf("Invalid Triangle");// in case property is not satisfied
    return 0;
}