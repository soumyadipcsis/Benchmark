/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
   /*                   PROBLEM
   You would be given three integers as input which corresponds to the three sides of a triangle. Write a program to determine if the triangle is acute, right or obtuse. You should print "Invalid Triangle" if the side combinations do not correspond to a valid triangle.     */
   
    int a,b,c,tmp;              //declaring variables(tmp for swapping)
    scanf("%d %d %d",&a,&b,&c); // taking the input
   
                /*   taking maximum of a b & c  in a*/   
   
    if (a<b)                    //  checking b/w a & b
    {                           //   swapping if a is not greater
       tmp=a;                   //  swapping  
       a=b;                     //   variables
       b=tmp;                   //    a  &  b 
    }
    if (a<c)                    //  checking b/w a & c
    {                           //   swapping if a is not greater
       tmp=a;                   //  swapping  
       a=c;                     //   variables
       c=tmp;                   //    a  &  c 
    }
                /*  Matching conditions and OUTPUT  */
    
    if (a >= (b + c))           // condition of invalid triangle
    {
        printf("Invalid Triangle");        // printing output
    }
    else if ( (a*a) > ( (b*b) + (c*c) ) )  // cond. of obtuse triangle
    {
        printf("Obtuse Triangle");         // printing output
    }
    else if ( (a*a) < ( (b*b) + (c*c) )  ) // cond. of acute triangle
    {
        printf("Acute Triangle");          // printing output
    }
    else                                   // otherwise right triangle
    {
        printf("Right Triangle");          // printing output
    }
    
    return 0;                              // end of programme
}