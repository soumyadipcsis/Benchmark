/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
     {int a,b,c,temp;
      scanf("%d%d%d",&a,&b,&c);//input a,b,c
      temp=c;//temporary variable c
     if(a>=c && a>=b)//checking if a is greatest
       {
           c=a;
           a=b;
           b=temp;
       }
     else if (b>=c&&b>=a)//checking if b is greatest 
        {
            c=b;
            b=a;
            a=temp;
        }
        
     if(((a+b)>c)&&((b+c)>a)&&((c+a)>b))// condition for triangle formation
      { 
          if((a*a)+(b*b) > (c*c))// condition for acute triangle
           { 
               printf("Acute Triangle");
           }
        else if((a*a+b*b)==(c*c))//condition for right triangle
          {  
              printf ("Right Triangle");
          }
        else 
           { 
               printf("Obtuse Triangle");
           }
      }
    else{printf("Invalid Triangle"); 
         }
    return 0;
   }