/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{ 
    int a,b,c;//varibles for 3 sides of the triangle.
    scanf("%d %d %d",&a,&b,&c);
    int larg=a;//varibale for largest side,assuming a is the largest.
    if((b>a)&&(b>c))/*condition for b to be largest*/
    {
        larg=b;//larg changed to b
    }
    else if((c>a)&&(c>b))//condition for c to be largest
    {
        larg=c;//larg changed to c
    }
    if((a<(b+c))&&(b<(a+c))&&(c<(a+b)))/*condition for triangle to exist*/
    {
        if(larg==a)
        {
            if((a*a)>((b*b)+(c*c)))/*square of largest side is greater than the sum to squares of other two side for obtuse*/
            {
                printf("Obtuse Triangle");
            }
            else if((a*a)<((b*b)+(c*c)))/*square of largest side is less than the sum to squares of other two side for acute*/
            {
                printf("Acute Triangle");
            }
            else if((a*a)==((b*b)+(c*c)))/*square of largest side is equal to the sum to squares of other two side for right angled*/
            {
                printf("Right Triangle");
            }
        
        }
        if(larg==b)//if larg is b
        {
            if((b*b)>((a*a)+(c*c)))/*square of largest side is greater than the sum to squares of other two side for obtuse*/
            {
                printf("Obtuse Triangle");
            }
            else if((b*b)<((a*a)+(c*c)))/*square of largest side is less than the sum to squares of other two side for acute*/
            {
                printf("Acute Triangle");
            }
            else if((b*b)==((a*a)+(c*c)))/*square of largest side is equal to the sum to squares of other two side for right angled*/
            {
                printf("Right Triangle");
            }
    
        }
        if(larg==c)//if larg is c
        {
            if((c*c)>((b*b)+(a*a)))/*square of largest side is greater than the sum to squares of other two side for obtuse*/
            {
                printf("Obtuse Triangle");
            }
            else if((c*c)<((b*b)+(a*a))/*square of largest side is less than the sum to squares of other two side for acute*/)
            {
                printf("Acute Triangle");
            }
            else if((c*c)==((b*b)+(a*a)))/*square of largest side is equal to the sum to squares of other two side for right angled*/
            {
                printf("Right Triangle");
            }

    
        }
    }
    else //if above condition fails
    {
        printf("Invalid Triangle");
    }
    return 0;
}