/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);//values inputed through user
    /* general algorithm for three sides to form a triangle*/
    if(a<b)
    {
        if(c<b)
        {
            int d;
            d=b;
            b=c;
            c=d;
        }

    }
    else if(a>b)
    {
        if(a<c)
        {
            int e;
            e=a;
            a=b;
            b=e;
        }
        else
        {
            if(b<c)
            {
                int f,g;
                f=a;
                a=b;
                b=f;
                g=b;
                b=c;
                c=g;
            }
            else
            {
                int h;
                h=a;
                a=c;
                c=h;
            }
        }
        
    }
    if(((a+b)>c)&&((a+c)>b)&&((b+c)>a))
    {
        if((a*a+b*b)>c*c)//condition for a triangle to be acute                                   triangle if values of sides are given                                  .(through cosine law)
        {
            printf("Acute Triangle");
        }
        else if((a*a+b*b)==c*c)//condition for a triangle to be right                                   triangle if values of sides are given
        {
            printf("Right Triangle");
        }
        else if((a*a+b*b)<c*c)//condition for a triangle to be obtuse
        {
            printf("Obtuse Triangle");
        }
    }
    else
    {
        printf("Invalid Triangle");
    }
    return 0;
}