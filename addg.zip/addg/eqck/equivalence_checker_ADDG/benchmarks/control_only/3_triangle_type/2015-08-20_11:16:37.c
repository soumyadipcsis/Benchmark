/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    int x=a*a;
    int y=b*b;
    int z=c*c;
    int cosa=(y+z-x)/2*b*c;
    int cosb=(x+z-y)/2*a*c;
    int cosc=(y+x-z)/2*b*a;
    if((x==y+z)||(y==x+z)||(z==x+y))
        {
            printf("Right Triangle");
        }
  if(((a+b>c)&&(b+c>a)&&(a+c>b))&&(cosa<0 || cosb<0 || cosc<0))    
        {
            printf("Obtuse Triangle");       
        }
    if(cosa>0 && cosb>0 && cosc>0)    
        {
            printf("Acute Triangle");       
        }    
     if((a+b<=c)||(b+c<=a)||(a+c<=b))
        {
            printf("Invalid Triangle");
            
        }
    return 0;
}