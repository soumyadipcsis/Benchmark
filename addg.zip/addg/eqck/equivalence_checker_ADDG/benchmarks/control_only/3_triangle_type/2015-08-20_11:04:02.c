/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()
{
    int a,b,c;
    int d=0;
    scanf("%d %d %d",&a,&b,&c);
    if (a<b||a<c)
    {
       if(b>=c)
        {
            d=a;
            a=b;
            b=d;
                            //finding max and swapping
        }
        else if(c>=b)
        {
            d=a;
            a=c;
            c=d;
        }
    }
    
    if ((b+c)<=a)               //condition check
    printf("Invalid Triangle");
    else
    
    {
    if((c*c+b*b)==a*a)
    printf("Right Triangle");   //right triangle
    
    else if((c*c+b*b)>a*a)
    printf("Acute Triangle");   //acute traingle
    
    else if((c*c+b*b)<a*a)
    printf("Obtuse Triangle");  //obtuse triangle
    
    }
    return 0;
}