/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile leep year*/
#include<stdio.h>

int main()
{
    int y;
    scanf("%d",&y);//taking input from user
    if(y%4==0)
    {if(y%100==0 && !(y%400==0))//applying condition
      printf("Not Leap Year");
      else//nested looping
        printf("Leap Year");//printing result
    }
    else
    printf("Not Leap Year");
    return 0;
}    
    
    // Fill this area with your code.
