/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile triangle*/
#include<stdio.h>

int main()
{     //block begins
    int a,b,c;     // initialising variables a,b,c  
    int max1,max2,max3;     // initialising variables max1, max2, max3
    scanf("%d%d%d",&a,&b,&c);   //initialising values to a,b,c
    if(a>=b&&a>=c)     
    {     //outer if begins, if a is maximum
        max1 = a;      //a is kept maximum
        if(b>=c)       
        {     //inner if begins, if b is greater than or equal                         to c 
            max2 = b;  //2nd maximum is kept to b
            max3 = c;  //3rd maximum is kept to c
        }     //inner if ends
        else           
        {     //inner else begins
            max2 = c;  //2nd maximum is kept to c
            max3 = b;  //3rd maximum is kept to b
        }     //inner else ends
    }     //outer if ends

    else if(b>=a&&b>=c)     
    {     // outerelse if begins, if b is maximum
        max1 = b;     //b is kept maximum    
        if(c>=a)     
        {     //inner if begins, if c is greater than or equal                         to a 
            max2 = c;     //2nd maximum is kept to c
            max3 = a;     //3rd maximum is kept to a
        }     //inner if ends
        else     
        {     //inner else begins 
            max2 = a;     //2nd maximum is kept to a
            max3 = c;     //3rd maximum is kept to c
        }     //inner else ends
    }     //outer else if ends

    else     
    {     //outer else begins
        max1 = c;      //b is kept maximum    
        if(a>=b )      
        {     //inner if begins, if a is greater than or equal                         to b
            max2 = a;     //2nd maximum is kept to a       
            max3 = b;     //3rd maximum is kept to b
        }     //inner if ends
        else     
        {     //inner else begins
            max2 = b;     //2nd maximum is kept to b
            max3 = a;     //3rd maximum is kept to a
        }     //inner else ends
    }     //outer else ends

    if(max1 < (max2 + max3))     
    {     //outer if begins
        if((max1*max1) < ((max2*max2) + (max3*max3)))
        {     //inner if begins, condition for acute triangle
            printf("Acute Triangle");      //prints acute triangle
        }     //inner if ends
        else if((max1*max1) == ((max2*max2) + (max3*max3)))
        {     //inner else if begins
            printf("Right Triangle");      //prints right triangle
        }     //inner else if ends
        else
        {     //inner else begins
            printf("Obtuse Triangle");      //prints obtuse triangle
        }     //inner else ends
    }      //outer if ends

    else
    {     //outer else begins
        printf("Invalid Triangle");      //prints invalid triangle
    }     //outer else ends
    return 0;
}      //block ends
