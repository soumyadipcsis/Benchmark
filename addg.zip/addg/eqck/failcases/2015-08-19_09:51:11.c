/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile 2nd largest*/
#include<stdio.h>

int main()
{   int a,b,c,d;
    scanf("%d%d%d%d",&a,&b,&c,&d);
    if (a>=b){
        if (b>=c){
            if (c>=d){
                printf("The second largest number is %d",b);
            }
            else if(d>=c){
                if(d>=b){
                    if(d<=a){
                    printf("The second largest number is %d",d);
                } else{
                    printf("The second largest number is %d",a);
                }
            }
            }
        } else {
            if(c>=a){
                printf("The second largest number is %d",a);
            } else {
                printf("The second largest number is %d",c);
            }
        }
    } else {
        if (a>=c){
            if (c>=d){
                printf("The second largest number is %d",a);
            }else {
                if (d>=a){
                    if (d>=b){
                        printf("The second largest number is %d",b);
                    }else {
                        printf("The second largest number ie %d",d);
                    }
                }
            }
        }else{
            if (c>=b){
                printf("The second largest number is %d",b);
            }else {
                printf("The second largest number is %d",c);
            }
            }
        }
        
    
    
     return 0;
            }
    // Fill this area with your code.
