/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int main()            //main() function declared
{
    int N,i,j;        //variables declared
    scanf("%d",&N);   //input N
    for(i=1;i<=N;i++) //outer loop for rows
    {
     for(j=N;j>0;j--) //inner loop
     {
       if(i==j)       //condition to print *            
        printf("*");
       else    
        printf("%d",j);
      }
     printf("\n");    //adds a new line  
    }
	return 0;
}                     //function ends